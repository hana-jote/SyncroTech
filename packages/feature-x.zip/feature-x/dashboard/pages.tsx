import { Dashboard } from "feature-x";

export default function Page() {
  return <Dashboard />;
}
